from flask import Flask, request, jsonify
import pandas as pd
import pickle

app = Flask(__name__)

# Load model
with open("model.pkl", "rb") as model_file:
    model = pickle.load(model_file)

FEATURE = ['suhu', 'ph_air', 'intensitas_cahaya']
LABEL = ['Bayam', 'Kangkung', 'Pakcoy', 'Sawi', 'Selada']

@app.route('/')
def home():
    return '''
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <title>Prediksi Tanaman Hidroponik</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 600px;
                margin: 40px auto;
                padding: 20px;
                border: 1px solid #ccc;
                border-radius: 8px;
                background-color: #f9f9f9;
            }
            h2, h3 {
                color: #2c3e50;
            }
            label {
                font-weight: bold;
            }
            input, button {
                width: 100%;
                padding: 10px;
                margin-top: 5px;
                margin-bottom: 15px;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            button {
                background-color: #27ae60;
                color: white;
                font-weight: bold;
                cursor: pointer;
            }
            button:hover {
                background-color: #219150;
            }
            #result {
                padding: 10px;
                background-color: #ecf0f1;
                border-left: 5px solid #27ae60;
                margin-top: 15px;
            }
        </style>
    </head>
    <body>
        <h2>Form Input Data Lingkungan</h2>
        <form id="predictForm">
            <label for="suhu">Suhu (°C):</label>
            <input type="number" step="0.1" id="suhu" required>

            <label for="ph_air">pH Air:</label>
            <input type="number" step="0.1" id="ph_air" required>

            <label for="intensitas_cahaya">Intensitas Cahaya (lux):</label>
            <input type="number" id="intensitas_cahaya" required>

            <button type="submit">Prediksi</button>
        </form>

        <h3>Hasil:</h3>
        <div id="result">Belum ada prediksi.</div>

        <script>
            document.getElementById("predictForm").addEventListener("submit", function (e) {
                e.preventDefault();

                const data = {
                    suhu: parseFloat(document.getElementById("suhu").value),
                    ph_air: parseFloat(document.getElementById("ph_air").value),
                    intensitas_cahaya: parseFloat(document.getElementById("intensitas_cahaya").value)
                };

                fetch("/predict", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(data)
                })
                .then(response => response.json())
                .then(json => {
                    if (json.status === "SUCCESS") {
                        document.getElementById("result").textContent = "Tanaman yang cocok: " + json.result;
                    } else {
                        document.getElementById("result").textContent = "Terjadi kesalahan: " + json.message;
                    }
                })
                .catch(err => {
                    document.getElementById("result").textContent = "Terjadi kesalahan: " + err;
                });
            });
        </script>
    </body>
    </html>
    '''

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()

    try:
        suhu = float(data['suhu'])
        ph_air = float(data['ph_air'])
        intensitas_cahaya = float(data['intensitas_cahaya'])

        new_data = pd.DataFrame([[suhu, ph_air, intensitas_cahaya]], columns=FEATURE)
        res = model.predict(new_data)
        result_label = LABEL[res[0]]

        return jsonify({
            "status": "SUCCESS",
            "input": {
                "suhu": suhu,
                "ph_air": ph_air,
                "intensitas_cahaya": intensitas_cahaya
            },
            "result": result_label
        }), 200

    except (KeyError, TypeError, ValueError) as e:
        return jsonify({
            "status": "ERROR",
            "message": str(e)
        }), 400

if __name__ == '__main__':
    app.run(debug=True)